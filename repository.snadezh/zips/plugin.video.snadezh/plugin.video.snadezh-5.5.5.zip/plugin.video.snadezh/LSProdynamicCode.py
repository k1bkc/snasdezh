#$pyFunction
import re,requests
def GetLSProData(page_data,Cookie_Jar,m):
  headers={'user-agent':'Mozilla/5.0','host':'dak1vd5vmi7x6.cloudfront.net','referer':'https://www.manototv.com/live','origin':'https://www.manototv.com','x-api-key':'8df22bad94a67c7fd25bd6492fba8328','accept':'application/json, text/plain, */*'}
  source=requests.get('https://dak1vd5vmi7x6.cloudfront.net/api/v1/publicrole/livemodule/details',headers=headers).content
  link=re.findall('"liveUrl":"([^"]+)',source)[0]
  m3u8=requests.get(link,headers={'user-agent':'Mozilla/5.0','host':'d2rwmwucnr0d10.cloudfront.net','referer':'https://www.manototv.com/live','accept':'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5'}).text
  if '2961200' in m3u8:
    return link.replace('/live','/live_2500')+'|user-agent=ipad&referer=https://www.manototv.com/live'
  elif '1861200' in m3u8:
    return link.replace('/live','/live_1500')+'|user-agent=ipad&referer=https://www.manototv.com/live'
  elif '1311200' in m3u8:
    return link.replace('/live','/live_1000')+'|user-agent=ipad&referer=https://www.manototv.com/live'
  else:
    return link.replace('/live','/live_750')+'|user-agent=ipad&referer=https://www.manototv.com/live'
